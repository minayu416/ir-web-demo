# log/urls.py
from django.conf.urls import url
from . import views
from main.views import index 
# We are adding a URL called /home
urlpatterns = [
    url(r'^$', index),
]
